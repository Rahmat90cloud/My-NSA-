package com.example

import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.service.DotNoteAccessibilityService
import com.example.ui.DotNoteApp
import com.example.ui.DotNoteViewModel
import com.example.ui.theme.DotNoteTheme
import kotlinx.coroutines.flow.MutableSharedFlow

class MainActivity : ComponentActivity() {

    private val viewModel: DotNoteViewModel by viewModels {
        val app = application as DotNoteApplication
        DotNoteViewModel.Factory(
            knowledgeRepository = app.knowledgeRepository,
            settingsRepository = app.settingsRepository
        )
    }

    private val inAppVolumeDownEvents = MutableSharedFlow<Unit>(extraBufferCapacity = 2)
    private var isTesterTabActive: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DotNoteTheme {
                DotNoteApp(
                    viewModel = viewModel,
                    inAppVolumeDownEvents = inAppVolumeDownEvents,
                    onActiveRouteChanged = { onTester ->
                        isTesterTabActive = onTester
                    }
                )
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN &&
            isTesterTabActive &&
            event?.repeatCount == 0 &&
            !DotNoteAccessibilityService.isServiceConnected.value
        ) {
            inAppVolumeDownEvents.tryEmit(Unit)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
