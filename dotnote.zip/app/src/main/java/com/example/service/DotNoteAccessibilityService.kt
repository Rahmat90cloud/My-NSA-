package com.example.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.util.DisplayMetrics
import android.view.Display
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.DotNoteApplication
import com.example.data.MatchHistoryEntity
import com.example.engine.OcrLine
import com.example.engine.OcrScreenResult
import com.example.engine.OfflineAnswerEngine
import com.example.engine.OfflineOcrProcessor
import com.example.engine.ScreenQuizParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean

class DotNoteAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var overlayManager: DotOverlayManager
    private val isProcessing = AtomicBoolean(false)

    @Volatile
    private var cachedArmed: Boolean = true

    @Volatile
    private var cachedConsumeKey: Boolean = true

    override fun onServiceConnected() {
        super.onServiceConnected()
        overlayManager = DotOverlayManager(this)
        _isServiceConnected.value = true

        val app = application as DotNoteApplication
        serviceScope.launch {
            app.settingsRepository.settingsFlow.collect { settings ->
                cachedArmed = settings.isServiceArmed
                cachedConsumeKey = settings.consumeVolumeKey
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Passive listener; processing only runs on Volume Down trigger.
    }

    override fun onInterrupt() {
        overlayManager.cleanup()
    }

    override fun onDestroy() {
        super.onDestroy()
        _isServiceConnected.value = false
        if (::overlayManager.isInitialized) {
            overlayManager.cleanup()
        }
        serviceScope.cancel()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && cachedArmed) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                triggerOfflineScan()
            }
            if (cachedConsumeKey) {
                return true
            }
        }
        return super.onKeyEvent(event)
    }

    private fun triggerOfflineScan() {
        if (!isProcessing.compareAndSet(false, true)) return
        val startTime = System.currentTimeMillis()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        val buffer = screenshot.hardwareBuffer
                        val colorSpace = screenshot.colorSpace
                        val hwBitmap = try {
                            Bitmap.wrapHardwareBuffer(buffer, colorSpace)
                        } catch (_: Throwable) {
                            null
                        }
                        val swBitmap = hwBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                        hwBitmap?.recycle()
                        buffer.close()

                        if (swBitmap != null) {
                            processBitmapAndShowDot(swBitmap, startTime)
                        } else {
                            processAccessibilityTreeFallback(startTime)
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        processAccessibilityTreeFallback(startTime)
                    }
                }
            )
        } else {
            processAccessibilityTreeFallback(startTime)
        }
    }

    private fun processBitmapAndShowDot(bitmap: Bitmap, startTime: Long) {
        serviceScope.launch {
            try {
                val app = application as DotNoteApplication
                val settings = app.settingsRepository.getCurrentSettings()

                val ocrResult = withContext(Dispatchers.Default) {
                    OfflineOcrProcessor.recognizeText(bitmap)
                }
                bitmap.recycle()

                val quiz = ScreenQuizParser.parse(ocrResult)
                    ?: run {
                        // Secondary fallback if OCR missed structured UI text
                        extractFromActiveWindow()?.let { ScreenQuizParser.parse(it) }
                    }

                if (quiz == null) return@launch

                val (chunks, mcqs) = app.knowledgeRepository.getAllChunksAndMcqs()
                val match = withContext(Dispatchers.Default) {
                    OfflineAnswerEngine.findBestAnswer(quiz, chunks, mcqs)
                } ?: return@launch

                overlayManager.showDotBesideBounds(
                    optionBounds = match.selectedOption.bounds,
                    screenWidth = ocrResult.imageWidth,
                    screenHeight = ocrResult.imageHeight,
                    dotSizeDp = settings.dotSizeDp,
                    offsetDp = settings.dotOffsetDp,
                    durationMs = settings.dotDurationMs
                )

                val elapsed = System.currentTimeMillis() - startTime
                app.knowledgeRepository.recordMatch(
                    MatchHistoryEntity(
                        capturedQuestion = quiz.questionText.take(240),
                        selectedOption = match.selectedOption.text.take(140),
                        confidence = match.confidence,
                        matchedSnippet = match.matchedSnippet.take(260),
                        sourceTitle = match.matchedSourceTitle,
                        triggerSource = "VOLUME_DOWN",
                        durationMs = elapsed
                    )
                )
            } catch (_: Throwable) {
            } finally {
                isProcessing.set(false)
            }
        }
    }

    private fun processAccessibilityTreeFallback(startTime: Long) {
        serviceScope.launch {
            try {
                val app = application as DotNoteApplication
                val settings = app.settingsRepository.getCurrentSettings()
                val fallbackOcr = extractFromActiveWindow() ?: return@launch
                val quiz = ScreenQuizParser.parse(fallbackOcr) ?: return@launch
                val (chunks, mcqs) = app.knowledgeRepository.getAllChunksAndMcqs()

                val match = withContext(Dispatchers.Default) {
                    OfflineAnswerEngine.findBestAnswer(quiz, chunks, mcqs)
                } ?: return@launch

                overlayManager.showDotBesideBounds(
                    optionBounds = match.selectedOption.bounds,
                    screenWidth = fallbackOcr.imageWidth,
                    screenHeight = fallbackOcr.imageHeight,
                    dotSizeDp = settings.dotSizeDp,
                    offsetDp = settings.dotOffsetDp,
                    durationMs = settings.dotDurationMs
                )

                val elapsed = System.currentTimeMillis() - startTime
                app.knowledgeRepository.recordMatch(
                    MatchHistoryEntity(
                        capturedQuestion = quiz.questionText.take(240),
                        selectedOption = match.selectedOption.text.take(140),
                        confidence = match.confidence,
                        matchedSnippet = match.matchedSnippet.take(260),
                        sourceTitle = match.matchedSourceTitle,
                        triggerSource = "VOLUME_DOWN",
                        durationMs = elapsed
                    )
                )
            } catch (_: Throwable) {
            } finally {
                isProcessing.set(false)
            }
        }
    }

    private fun extractFromActiveWindow(): OcrScreenResult? {
        val root = rootInActiveWindow ?: return null
        val (screenW, screenH) = getScreenDimensions()
        val lines = mutableListOf<OcrLine>()
        var blockCounter = 0

        fun traverse(node: AccessibilityNodeInfo?) {
            if (node == null) return
            if (node.isVisibleToUser) {
                val text = node.text?.toString()?.trim()
                    ?.ifEmpty { node.contentDescription?.toString()?.trim() }
                if (!text.isNullOrEmpty() && text.length >= 2) {
                    val rect = Rect()
                    node.getBoundsInScreen(rect)
                    if (!rect.isEmpty && rect.width() > 10 && rect.height() > 10) {
                        lines.add(OcrLine(text = text, bounds = rect, blockIndex = blockCounter++))
                    }
                }
            }
            for (i in 0 until node.childCount) {
                traverse(node.getChild(i))
            }
        }

        traverse(root)
        if (lines.isEmpty()) return null

        val sorted = lines.sortedWith(compareBy({ it.bounds.top }, { it.bounds.left }))
        return OcrScreenResult(
            lines = sorted,
            fullText = sorted.joinToString("\n") { it.text },
            imageWidth = screenW,
            imageHeight = screenH
        )
    }

    @Suppress("DEPRECATION")
    private fun getScreenDimensions(): Pair<Int, Int> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            val metrics = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(metrics)
            metrics.widthPixels to metrics.heightPixels
        }
    }

    companion object {
        private val _isServiceConnected = MutableStateFlow(false)
        val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()
    }
}
