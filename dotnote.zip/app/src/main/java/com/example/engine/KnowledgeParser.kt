package com.example.engine

import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

data class ParsedChunk(
    val index: Int,
    val content: String,
    val normalizedTokens: String,
    val keywords: String
)

data class ParsedMcq(
    val question: String,
    val options: List<String>,
    val correctAnswer: String,
    val normalizedQuestion: String
)

data class ParsedKnowledge(
    val chunks: List<ParsedChunk>,
    val mcqs: List<ParsedMcq>
)

object KnowledgeParser {

    private val json = Json { ignoreUnknownKeys = true }

    private val OPTION_LINE_REGEX = Regex("^\\s*(?:[\\(\\[]?([A-Ea-e1-5])[\\)\\].:\\-])\\s+(.+)$")
    private val ANSWER_LINE_REGEX = Regex(
        "^\\s*(?:ans(?:wer)?|correct(?:\\s+answer)?|key|solution)\\s*[:\\-=]\\s*(.+)$",
        RegexOption.IGNORE_CASE
    )
    private val QUESTION_PREFIX_REGEX = Regex(
        "^\\s*(?:q(?:uestion)?\\s*\\d*\\s*[:.\\-\\)]|\\d+[.)])\\s+(.+)$",
        RegexOption.IGNORE_CASE
    )
    private val QA_INLINE_REGEX = Regex(
        "^\\s*(?:q(?:uestion)?\\s*\\d*\\s*[:.\\-])\\s*(.+?)\\s+(?:ans(?:wer)?\\s*[:.\\-])\\s*(.+)$",
        RegexOption.IGNORE_CASE
    )

    fun parse(rawText: String): ParsedKnowledge {
        val normalizedNewlines = rawText.replace("\r\n", "\n").replace('\r', '\n').trim()
        if (normalizedNewlines.isEmpty()) {
            return ParsedKnowledge(emptyList(), emptyList())
        }

        val mcqs = extractMcqs(normalizedNewlines)
        val chunks = buildSemanticChunks(normalizedNewlines)

        // Also index each MCQ as a compact searchable chunk so passage matching can leverage it too
        val combinedChunks = chunks.toMutableList()
        val startIndex = combinedChunks.size
        mcqs.forEachIndexed { idx, mcq ->
            val summaryText = buildString {
                append(mcq.question)
                append(" Answer: ")
                append(mcq.correctAnswer)
            }
            val tokens = TextNormalizer.tokenize(summaryText)
            if (tokens.isNotEmpty()) {
                val topKeywords = tokens.groupingBy { it }.eachCount()
                    .entries.sortedByDescending { it.value }
                    .take(10).joinToString(",") { it.key }
                combinedChunks.add(
                    ParsedChunk(
                        index = startIndex + idx,
                        content = summaryText,
                        normalizedTokens = tokens.joinToString(" "),
                        keywords = topKeywords
                    )
                )
            }
        }

        return ParsedKnowledge(chunks = combinedChunks, mcqs = mcqs)
    }

    private fun extractMcqs(text: String): List<ParsedMcq> {
        val results = mutableListOf<ParsedMcq>()
        val lines = text.lines()

        var currentQuestion: String? = null
        val currentOptions = linkedMapOf<String, String>() // label -> option text
        var pendingQaQuestion: String? = null

        fun flushMcq(rawAnswer: String) {
            val q = currentQuestion?.trim() ?: return
            if (q.length < 4) return
            val ansTrimmed = rawAnswer.trim()
            if (ansTrimmed.isEmpty()) return

            // Resolve letter/number answer (e.g. "B" or "B) Mitochondria") to full option text if available
            val letterOnly = Regex("^([A-Ea-e1-5])(?:[\\)\\].:\\-\\s].*)?$").find(ansTrimmed)?.groupValues?.get(1)?.uppercase()
            val resolvedAnswer = if (letterOnly != null && currentOptions.containsKey(letterOnly)) {
                currentOptions[letterOnly] ?: ansTrimmed
            } else {
                // Check if answer starts with "B) text"
                val stripped = OPTION_LINE_REGEX.find(ansTrimmed)?.groupValues?.get(2)?.trim()
                stripped ?: ansTrimmed
            }

            val normQ = TextNormalizer.tokenize(q).joinToString(" ")
            results.add(
                ParsedMcq(
                    question = q,
                    options = currentOptions.values.toList(),
                    correctAnswer = resolvedAnswer,
                    normalizedQuestion = normQ
                )
            )
            currentQuestion = null
            currentOptions.clear()
        }

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isEmpty()) {
                continue
            }

            // Inline Q: ... A: ...
            val inlineMatch = QA_INLINE_REGEX.find(line)
            if (inlineMatch != null) {
                val q = inlineMatch.groupValues[1].trim()
                val a = inlineMatch.groupValues[2].trim()
                if (q.isNotEmpty() && a.isNotEmpty()) {
                    results.add(
                        ParsedMcq(
                            question = q,
                            options = emptyList(),
                            correctAnswer = a,
                            normalizedQuestion = TextNormalizer.tokenize(q).joinToString(" ")
                        )
                    )
                }
                currentQuestion = null
                currentOptions.clear()
                pendingQaQuestion = null
                continue
            }

            // Answer line: "Answer: B" or "Ans: Mitochondria"
            val ansMatch = ANSWER_LINE_REGEX.find(line)
            if (ansMatch != null) {
                val ansText = ansMatch.groupValues[1].trim()
                if (currentQuestion != null) {
                    flushMcq(ansText)
                } else if (pendingQaQuestion != null) {
                    results.add(
                        ParsedMcq(
                            question = pendingQaQuestion,
                            options = emptyList(),
                            correctAnswer = ansText,
                            normalizedQuestion = TextNormalizer.tokenize(pendingQaQuestion).joinToString(" ")
                        )
                    )
                    pendingQaQuestion = null
                }
                continue
            }

            // Option line: "A) Option text" or "a. Option text"
            val optMatch = OPTION_LINE_REGEX.find(line)
            if (optMatch != null && (currentQuestion != null || currentOptions.isNotEmpty())) {
                val key = optMatch.groupValues[1].uppercase()
                val optText = optMatch.groupValues[2].trim()
                currentOptions[key] = optText
                continue
            }

            // Question line: "Q1: ..." or "1. ...?" or ends with '?'
            val qMatch = QUESTION_PREFIX_REGEX.find(line)
            if (qMatch != null) {
                val candidate = qMatch.groupValues[1].trim()
                if (candidate.endsWith("?") || line.startsWith("Q", ignoreCase = true)) {
                    currentQuestion = candidate
                    currentOptions.clear()
                    pendingQaQuestion = candidate
                    continue
                }
            }

            if (line.endsWith("?") && line.length >= 8) {
                currentQuestion = line
                currentOptions.clear()
                pendingQaQuestion = line
                continue
            }

            // If we are inside a multi-line question before options start
            if (currentQuestion != null && currentOptions.isEmpty() && !line.contains(":")) {
                currentQuestion = "$currentQuestion $line"
            }
        }

        return results.distinctBy { it.question.lowercase() to it.correctAnswer.lowercase() }
    }

    private fun buildSemanticChunks(text: String): List<ParsedChunk> {
        val paragraphs = text.split(Regex("\\n\\s*\\n+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        val rawBlocks = mutableListOf<String>()
        for (para in paragraphs) {
            if (para.length <= 480) {
                rawBlocks.add(para)
            } else {
                // Split long chapters/notes by sentence boundaries with slight overlap
                val sentences = para.split(Regex("(?<=[.!?])\\s+|\\n+"))
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                val buffer = StringBuilder()
                var lastSentence = ""
                for (sentence in sentences) {
                    if (buffer.length + sentence.length > 460 && buffer.isNotEmpty()) {
                        rawBlocks.add(buffer.toString().trim())
                        buffer.clear()
                        if (lastSentence.length <= 160) {
                            buffer.append(lastSentence).append(" ")
                        }
                    }
                    buffer.append(sentence).append(" ")
                    lastSentence = sentence
                }
                if (buffer.isNotBlank()) {
                    rawBlocks.add(buffer.toString().trim())
                }
            }
        }

        return rawBlocks.mapIndexedNotNull { idx, block ->
            val tokens = TextNormalizer.tokenize(block)
            if (tokens.isEmpty()) return@mapIndexedNotNull null
            val topKeywords = tokens.groupingBy { it }.eachCount()
                .entries.sortedByDescending { it.value }
                .take(12).joinToString(",") { it.key }
            ParsedChunk(
                index = idx,
                content = block,
                normalizedTokens = tokens.joinToString(" "),
                keywords = topKeywords
            )
        }
    }

    fun encodeOptionsJson(options: List<String>): String = json.encodeToString(options)
}
