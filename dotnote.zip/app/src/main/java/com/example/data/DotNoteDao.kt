package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface KnowledgeDao {
    @Query("SELECT * FROM knowledge_documents ORDER BY createdAt DESC")
    fun observeAllDocuments(): Flow<List<KnowledgeDocumentEntity>>

    @Query("SELECT COUNT(*) FROM knowledge_documents")
    fun observeDocumentCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM knowledge_chunks")
    fun observeChunkCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM mcq_items")
    fun observeMcqCount(): Flow<Int>

    @Query("SELECT COALESCE(SUM(charCount), 0) FROM knowledge_documents")
    fun observeTotalChars(): Flow<Int>

    @Query("SELECT * FROM knowledge_chunks WHERE documentId = :documentId ORDER BY chunkIndex ASC")
    suspend fun getChunksForDocument(documentId: Long): List<KnowledgeChunkEntity>

    @Query("SELECT * FROM mcq_items WHERE documentId = :documentId ORDER BY id ASC")
    suspend fun getMcqsForDocument(documentId: Long): List<McqItemEntity>

    @Query("SELECT * FROM knowledge_chunks")
    suspend fun getAllChunks(): List<KnowledgeChunkEntity>

    @Query("SELECT * FROM mcq_items")
    suspend fun getAllMcqs(): List<McqItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(document: KnowledgeDocumentEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChunks(chunks: List<KnowledgeChunkEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMcqs(mcqs: List<McqItemEntity>)

    @Query("DELETE FROM knowledge_documents WHERE id = :documentId")
    suspend fun deleteDocumentById(documentId: Long)

    @Query("DELETE FROM knowledge_documents")
    suspend fun clearAllDocuments()
}

@Dao
interface MatchHistoryDao {
    @Query("SELECT * FROM match_history ORDER BY timestamp DESC LIMIT 50")
    fun observeRecentHistory(): Flow<List<MatchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(entry: MatchHistoryEntity)

    @Query("DELETE FROM match_history")
    suspend fun clearHistory()
}
