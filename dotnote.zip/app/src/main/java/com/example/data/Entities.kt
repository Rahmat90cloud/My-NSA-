package com.example.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "knowledge_documents")
data class KnowledgeDocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val sourceType: String, // "PASTE" or "TXT_FILE"
    val rawContent: String,
    val chunkCount: Int,
    val mcqCount: Int,
    val charCount: Int,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "knowledge_chunks",
    foreignKeys = [
        ForeignKey(
            entity = KnowledgeDocumentEntity::class,
            parentColumns = ["id"],
            childColumns = ["documentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["documentId"])]
)
data class KnowledgeChunkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentId: Long,
    val documentTitle: String,
    val chunkIndex: Int,
    val content: String,
    val normalizedTokens: String,
    val keywords: String
)

@Entity(
    tableName = "mcq_items",
    foreignKeys = [
        ForeignKey(
            entity = KnowledgeDocumentEntity::class,
            parentColumns = ["id"],
            childColumns = ["documentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["documentId"])]
)
data class McqItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentId: Long,
    val documentTitle: String,
    val question: String,
    val optionsJson: String,
    val correctAnswer: String,
    val normalizedQuestion: String
)

@Entity(tableName = "match_history")
data class MatchHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val capturedQuestion: String,
    val selectedOption: String,
    val confidence: Float,
    val matchedSnippet: String,
    val sourceTitle: String,
    val triggerSource: String, // "VOLUME_DOWN" or "IN_APP_TEST"
    val durationMs: Long,
    val timestamp: Long = System.currentTimeMillis()
)

data class KnowledgeStats(
    val documentCount: Int = 0,
    val chunkCount: Int = 0,
    val mcqCount: Int = 0,
    val totalChars: Int = 0
)
