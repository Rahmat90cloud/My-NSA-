package com.example.data

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import com.example.engine.KnowledgeParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.withContext

data class IngestionResult(
    val documentId: Long,
    val title: String,
    val chunkCount: Int,
    val mcqCount: Int,
    val charCount: Int
)

class KnowledgeRepository(
    private val knowledgeDao: KnowledgeDao,
    private val matchHistoryDao: MatchHistoryDao
) {

    val documentsFlow: Flow<List<KnowledgeDocumentEntity>> = knowledgeDao.observeAllDocuments()

    val statsFlow: Flow<KnowledgeStats> = combine(
        knowledgeDao.observeDocumentCount(),
        knowledgeDao.observeChunkCount(),
        knowledgeDao.observeMcqCount(),
        knowledgeDao.observeTotalChars()
    ) { docs, chunks, mcqs, chars ->
        KnowledgeStats(
            documentCount = docs,
            chunkCount = chunks,
            mcqCount = mcqs,
            totalChars = chars
        )
    }

    val recentHistoryFlow: Flow<List<MatchHistoryEntity>> = matchHistoryDao.observeRecentHistory()

    suspend fun ingestPastedText(titleInput: String, rawText: String): Result<IngestionResult> =
        withContext(Dispatchers.IO) {
            runCatching {
                val cleanText = rawText.trim()
                require(cleanText.isNotEmpty()) { "Text cannot be empty." }
                val title = titleInput.trim().ifEmpty {
                    cleanText.lineSequence().firstOrNull { it.isNotBlank() }
                        ?.take(42)?.trim() ?: "Pasted Study Notes"
                }
                persistParsedDocument(title = title, sourceType = "PASTE", rawText = cleanText)
            }
        }

    suspend fun ingestTxtFile(uri: Uri, contentResolver: ContentResolver): Result<IngestionResult> =
        withContext(Dispatchers.IO) {
            runCatching {
                val fileName = resolveFileName(uri, contentResolver) ?: "Imported Notes.txt"
                val content = contentResolver.openInputStream(uri)?.use { stream ->
                    stream.bufferedReader(Charsets.UTF_8).readText()
                } ?: error("Unable to read selected file.")

                val cleanText = content.trim()
                require(cleanText.isNotEmpty()) { "The selected TXT file is empty." }
                val title = fileName.removeSuffix(".txt").removeSuffix(".TXT").ifBlank { "Imported TXT" }
                persistParsedDocument(title = title, sourceType = "TXT_FILE", rawText = cleanText)
            }
        }

    private suspend fun persistParsedDocument(
        title: String,
        sourceType: String,
        rawText: String
    ): IngestionResult {
        val parsed = KnowledgeParser.parse(rawText)
        val docId = knowledgeDao.insertDocument(
            KnowledgeDocumentEntity(
                title = title,
                sourceType = sourceType,
                rawContent = rawText,
                chunkCount = parsed.chunks.size,
                mcqCount = parsed.mcqs.size,
                charCount = rawText.length
            )
        )

        if (parsed.chunks.isNotEmpty()) {
            knowledgeDao.insertChunks(
                parsed.chunks.map { chunk ->
                    KnowledgeChunkEntity(
                        documentId = docId,
                        documentTitle = title,
                        chunkIndex = chunk.index,
                        content = chunk.content,
                        normalizedTokens = chunk.normalizedTokens,
                        keywords = chunk.keywords
                    )
                }
            )
        }

        if (parsed.mcqs.isNotEmpty()) {
            knowledgeDao.insertMcqs(
                parsed.mcqs.map { mcq ->
                    McqItemEntity(
                        documentId = docId,
                        documentTitle = title,
                        question = mcq.question,
                        optionsJson = KnowledgeParser.encodeOptionsJson(mcq.options),
                        correctAnswer = mcq.correctAnswer,
                        normalizedQuestion = mcq.normalizedQuestion
                    )
                }
            )
        }

        return IngestionResult(
            documentId = docId,
            title = title,
            chunkCount = parsed.chunks.size,
            mcqCount = parsed.mcqs.size,
            charCount = rawText.length
        )
    }

    suspend fun getDocumentDetails(documentId: Long): Pair<List<KnowledgeChunkEntity>, List<McqItemEntity>> =
        withContext(Dispatchers.IO) {
            knowledgeDao.getChunksForDocument(documentId) to knowledgeDao.getMcqsForDocument(documentId)
        }

    suspend fun getAllChunksAndMcqs(): Pair<List<KnowledgeChunkEntity>, List<McqItemEntity>> =
        withContext(Dispatchers.IO) {
            knowledgeDao.getAllChunks() to knowledgeDao.getAllMcqs()
        }

    suspend fun deleteDocument(documentId: Long) = withContext(Dispatchers.IO) {
        knowledgeDao.deleteDocumentById(documentId)
    }

    suspend fun clearAllKnowledge() = withContext(Dispatchers.IO) {
        knowledgeDao.clearAllDocuments()
    }

    suspend fun recordMatch(entry: MatchHistoryEntity) = withContext(Dispatchers.IO) {
        matchHistoryDao.insertHistory(entry)
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        matchHistoryDao.clearHistory()
    }

    private fun resolveFileName(uri: Uri, contentResolver: ContentResolver): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) return cursor.getString(idx)
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }
}
