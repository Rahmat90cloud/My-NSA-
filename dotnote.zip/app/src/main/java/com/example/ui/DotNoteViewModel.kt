package com.example.ui

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.Rect
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.KnowledgeChunkEntity
import com.example.data.KnowledgeDocumentEntity
import com.example.data.KnowledgeRepository
import com.example.data.KnowledgeStats
import com.example.data.MatchHistoryEntity
import com.example.data.McqItemEntity
import com.example.data.SettingsRepository
import com.example.data.TriggerSettings
import com.example.engine.AnswerMatchResult
import com.example.engine.DetectedQuiz
import com.example.engine.OcrScreenResult
import com.example.engine.OfflineAnswerEngine
import com.example.engine.OfflineOcrProcessor
import com.example.engine.ScreenQuizParser
import com.example.service.DotNoteAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class DocumentDetailState(
    val document: KnowledgeDocumentEntity,
    val chunks: List<KnowledgeChunkEntity>,
    val mcqs: List<McqItemEntity>
)

data class LiveTestResult(
    val ocrResult: OcrScreenResult,
    val detectedQuiz: DetectedQuiz?,
    val matchResult: AnswerMatchResult?,
    val elapsedMs: Long,
    val dotBounds: Rect?,
    val showDotNow: Boolean,
    val errorMessage: String? = null
)

class DotNoteViewModel(
    private val knowledgeRepository: KnowledgeRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val documents: StateFlow<List<KnowledgeDocumentEntity>> =
        knowledgeRepository.documentsFlow.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val stats: StateFlow<KnowledgeStats> =
        knowledgeRepository.statsFlow.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = KnowledgeStats()
        )

    val settings: StateFlow<TriggerSettings> =
        settingsRepository.settingsFlow.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = TriggerSettings()
        )

    val recentHistory: StateFlow<List<MatchHistoryEntity>> =
        knowledgeRepository.recentHistoryFlow.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val isServiceConnected: StateFlow<Boolean> = DotNoteAccessibilityService.isServiceConnected

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _documentDetail = MutableStateFlow<DocumentDetailState?>(null)
    val documentDetail: StateFlow<DocumentDetailState?> = _documentDetail.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _liveTestResult = MutableStateFlow<LiveTestResult?>(null)
    val liveTestResult: StateFlow<LiveTestResult?> = _liveTestResult.asStateFlow()

    private val _snackbarEvents = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val snackbarEvents: SharedFlow<String> = _snackbarEvents.asSharedFlow()

    private var dotHideJob: Job? = null

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun ingestPastedText(title: String, rawText: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = knowledgeRepository.ingestPastedText(title, rawText)
            _isBusy.value = false
            result.onSuccess { ingested ->
                _snackbarEvents.tryEmit(
                    "Saved \"${ingested.title}\" (${ingested.chunkCount} chunks, ${ingested.mcqCount} Q&As)"
                )
                onSuccess()
            }.onFailure { err ->
                _snackbarEvents.tryEmit(err.message ?: "Failed to process text.")
            }
        }
    }

    fun ingestTxtFiles(uris: List<Uri>, contentResolver: ContentResolver) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _isBusy.value = true
            var totalFiles = 0
            var totalChunks = 0
            var totalMcqs = 0
            for (uri in uris) {
                knowledgeRepository.ingestTxtFile(uri, contentResolver)
                    .onSuccess { res ->
                        totalFiles++
                        totalChunks += res.chunkCount
                        totalMcqs += res.mcqCount
                    }
            }
            _isBusy.value = false
            if (totalFiles > 0) {
                _snackbarEvents.tryEmit(
                    "Imported $totalFiles TXT file(s): $totalChunks chunks, $totalMcqs Q&As indexed"
                )
            } else {
                _snackbarEvents.tryEmit("Could not read selected TXT file(s).")
            }
        }
    }

    fun openDocumentDetail(doc: KnowledgeDocumentEntity) {
        viewModelScope.launch {
            val (chunks, mcqs) = knowledgeRepository.getDocumentDetails(doc.id)
            _documentDetail.value = DocumentDetailState(doc, chunks, mcqs)
        }
    }

    fun closeDocumentDetail() {
        _documentDetail.value = null
    }

    fun deleteDocument(docId: Long) {
        viewModelScope.launch {
            knowledgeRepository.deleteDocument(docId)
            if (_documentDetail.value?.document?.id == docId) {
                _documentDetail.value = null
            }
            _snackbarEvents.tryEmit("Removed document from local SQLite store.")
        }
    }

    fun clearAllKnowledge() {
        viewModelScope.launch {
            knowledgeRepository.clearAllKnowledge()
            _documentDetail.value = null
            _snackbarEvents.tryEmit("Cleared all stored knowledge.")
        }
    }

    fun loadSampleStudyPack() {
        val sampleNotes = """
            Cellular Biology & Biochemistry Notes

            The mitochondrion is known as the powerhouse of the cell because it generates most of the cell's supply of adenosine triphosphate (ATP), used as a source of chemical energy.
            Ribosomes are responsible for synthesizing proteins by translating messenger RNA (mRNA) sequences into polypeptide chains.
            Photosynthesis occurs inside chloroplasts in plant cells, converting carbon dioxide and water into glucose and oxygen using sunlight.
            The Golgi apparatus modifies, sorts, and packages proteins and lipids for secretion or delivery to other organelles.

            Computer Networks & OS Fundamentals

            Q: Which transport layer protocol provides connectionless, low-overhead delivery without guaranteed ordering?
            A) TCP
            B) UDP
            C) HTTP
            D) SSH
            Answer: B

            Q: What is the time complexity of binary search on a sorted array of n elements?
            A) O(n)
            B) O(n log n)
            C) O(log n)
            D) O(1)
            Answer: C

            Deadlock in operating systems occurs when four Coffman conditions hold simultaneously: mutual exclusion, hold and wait, no preemption, and circular wait.
            The Page Table maps virtual memory addresses to physical RAM frame addresses via the Memory Management Unit (MMU).
        """.trimIndent()

        ingestPastedText(
            title = "Sample Biology & CS Study Pack",
            rawText = sampleNotes
        )
    }

    fun runOfflineScanOnBitmap(bitmap: Bitmap, recycleBitmap: Boolean = true) {
        viewModelScope.launch {
            val start = System.currentTimeMillis()
            _isBusy.value = true
            try {
                val ocrResult = withContext(Dispatchers.Default) {
                    OfflineOcrProcessor.recognizeText(bitmap)
                }
                if (recycleBitmap) {
                    bitmap.recycle()
                }

                val quiz = withContext(Dispatchers.Default) {
                    ScreenQuizParser.parse(ocrResult)
                }

                if (quiz == null) {
                    _liveTestResult.value = LiveTestResult(
                        ocrResult = ocrResult,
                        detectedQuiz = null,
                        matchResult = null,
                        elapsedMs = System.currentTimeMillis() - start,
                        dotBounds = null,
                        showDotNow = false,
                        errorMessage = "OCR read text, but could not detect a question with 2+ options."
                    )
                    return@launch
                }

                val (chunks, mcqs) = knowledgeRepository.getAllChunksAndMcqs()
                if (chunks.isEmpty() && mcqs.isEmpty()) {
                    _liveTestResult.value = LiveTestResult(
                        ocrResult = ocrResult,
                        detectedQuiz = quiz,
                        matchResult = null,
                        elapsedMs = System.currentTimeMillis() - start,
                        dotBounds = null,
                        showDotNow = false,
                        errorMessage = "Knowledge base is empty. Paste notes or import a TXT file first."
                    )
                    return@launch
                }

                val match = withContext(Dispatchers.Default) {
                    OfflineAnswerEngine.findBestAnswer(quiz, chunks, mcqs)
                }

                val elapsed = System.currentTimeMillis() - start
                val currentSettings = settingsRepository.getCurrentSettings()

                if (match != null) {
                    knowledgeRepository.recordMatch(
                        MatchHistoryEntity(
                            capturedQuestion = quiz.questionText.take(240),
                            selectedOption = match.selectedOption.text.take(140),
                            confidence = match.confidence,
                            matchedSnippet = match.matchedSnippet.take(260),
                            sourceTitle = match.matchedSourceTitle,
                            triggerSource = "IN_APP_TEST",
                            durationMs = elapsed
                        )
                    )
                }

                _liveTestResult.value = LiveTestResult(
                    ocrResult = ocrResult,
                    detectedQuiz = quiz,
                    matchResult = match,
                    elapsedMs = elapsed,
                    dotBounds = match?.selectedOption?.bounds,
                    showDotNow = match != null,
                    errorMessage = if (match == null) "No matching answer found in stored knowledge." else null
                )

                if (match != null) {
                    dotHideJob?.cancel()
                    dotHideJob = viewModelScope.launch {
                        delay(currentSettings.dotDurationMs)
                        _liveTestResult.value = _liveTestResult.value?.copy(showDotNow = false)
                    }
                }
            } catch (t: Throwable) {
                _snackbarEvents.tryEmit(t.message ?: "Offline OCR scan failed.")
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun replayDotFlash() {
        val current = _liveTestResult.value ?: return
        if (current.dotBounds == null) return
        dotHideJob?.cancel()
        dotHideJob = viewModelScope.launch {
            val duration = settingsRepository.getCurrentSettings().dotDurationMs
            _liveTestResult.value = current.copy(showDotNow = true)
            delay(duration)
            _liveTestResult.value = _liveTestResult.value?.copy(showDotNow = false)
        }
    }

    fun clearLiveTestResult() {
        dotHideJob?.cancel()
        _liveTestResult.value = null
    }

    fun setServiceArmed(armed: Boolean) {
        viewModelScope.launch { settingsRepository.setServiceArmed(armed) }
    }

    fun setConsumeVolumeKey(consume: Boolean) {
        viewModelScope.launch { settingsRepository.setConsumeVolumeKey(consume) }
    }

    fun setDotSizeDp(sizeDp: Float) {
        viewModelScope.launch { settingsRepository.setDotSizeDp(sizeDp) }
    }

    fun setDotDurationMs(durationMs: Long) {
        viewModelScope.launch { settingsRepository.setDotDurationMs(durationMs) }
    }

    fun setDotOffsetDp(offsetDp: Float) {
        viewModelScope.launch { settingsRepository.setDotOffsetDp(offsetDp) }
    }

    fun clearHistory() {
        viewModelScope.launch {
            knowledgeRepository.clearHistory()
            _snackbarEvents.tryEmit("Match history cleared.")
        }
    }

    class Factory(
        private val knowledgeRepository: KnowledgeRepository,
        private val settingsRepository: SettingsRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DotNoteViewModel(knowledgeRepository, settingsRepository) as T
        }
    }
}
