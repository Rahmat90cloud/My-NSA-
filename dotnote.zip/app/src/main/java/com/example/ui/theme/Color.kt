package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette: Scholarly Paper & Crisp Signal Ink
val PaperBackground = Color(0xFFFAF9F6)
val PaperSurface = Color(0xFFFFFFFF)
val PaperSurfaceVariant = Color(0xFFF1EFE9)
val PaperOutline = Color(0xFFE0DDD4)

val InkPrimary = Color(0xFF141824)
val InkSecondary = Color(0xFF4A5060)
val CobaltAccent = Color(0xFF2454A6)
val CobaltContainer = Color(0xFFDCE6F7)
val EmeraldSignal = Color(0xFF0E7C58)
val EmeraldContainer = Color(0xFFD3F3E6)
val AmberWarm = Color(0xFFB4690E)
val AmberContainer = Color(0xFFFBECD5)
val CrimsonError = Color(0xFFBA1A1A)
val CrimsonContainer = Color(0xFFFFDAD6)

// Dark Palette: Deep Graphite Study & Mint Signal
val DarkPaperBackground = Color(0xFF10131A)
val DarkPaperSurface = Color(0xFF181C26)
val DarkPaperSurfaceVariant = Color(0xFF232836)
val DarkPaperOutline = Color(0xFF33394A)

val DarkInkPrimary = Color(0xFFF2F0EA)
val DarkInkSecondary = Color(0xFFB5BAC7)
val DarkCobaltAccent = Color(0xFF8BB4F8)
val DarkCobaltContainer = Color(0xFF1D3561)
val DarkEmeraldSignal = Color(0xFF4AE2A8)
val DarkEmeraldContainer = Color(0xFF0A4732)
val DarkAmberWarm = Color(0xFFFFCA7A)
val DarkAmberContainer = Color(0xFF4A2E05)
