package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val DarkColorScheme = darkColorScheme(
    primary = DarkCobaltAccent,
    onPrimary = Color(0xFF0A1D42),
    primaryContainer = DarkCobaltContainer,
    onPrimaryContainer = DarkInkPrimary,
    secondary = DarkEmeraldSignal,
    onSecondary = Color(0xFF04291C),
    secondaryContainer = DarkEmeraldContainer,
    onSecondaryContainer = Color(0xFFA7F7D4),
    tertiary = DarkAmberWarm,
    tertiaryContainer = DarkAmberContainer,
    background = DarkPaperBackground,
    onBackground = DarkInkPrimary,
    surface = DarkPaperSurface,
    onSurface = DarkInkPrimary,
    surfaceVariant = DarkPaperSurfaceVariant,
    onSurfaceVariant = DarkInkSecondary,
    outline = DarkPaperOutline
)

private val LightColorScheme = lightColorScheme(
    primary = CobaltAccent,
    onPrimary = Color.White,
    primaryContainer = CobaltContainer,
    onPrimaryContainer = InkPrimary,
    secondary = EmeraldSignal,
    onSecondary = Color.White,
    secondaryContainer = EmeraldContainer,
    onSecondaryContainer = Color(0xFF053827),
    tertiary = AmberWarm,
    tertiaryContainer = AmberContainer,
    background = PaperBackground,
    onBackground = InkPrimary,
    surface = PaperSurface,
    onSurface = InkPrimary,
    surfaceVariant = PaperSurfaceVariant,
    onSurfaceVariant = InkSecondary,
    outline = PaperOutline,
    error = CrimsonError,
    errorContainer = CrimsonContainer
)

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun DotNoteTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
